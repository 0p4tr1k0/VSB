#pragma once
#include <iostream>
#include <vector>

// function that generates all permutation from 1 to n
void generate_permutations(int n);
void print_permutation(const std::vector<int> &array);

// function that return index of the element i am looking for in sorted array
int binary_search(int target, const std::vector<int> &sorted_array);
