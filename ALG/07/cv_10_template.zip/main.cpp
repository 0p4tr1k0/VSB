#include <iostream>
#include "cv_10.hpp"

using namespace std;

int main()
{
    generate_permutations(3);

    /*int x = 256;
    //int x = 667;
    int ind = binary_search(x, sorted_array);
    if (ind == -1)
    {
        cout << "number: " << x << " is not in the array." << endl;
    }
    else
    {
        cout << "number: " << x << " is on the index: " << ind << endl;
    }
    */
    return 0;
}